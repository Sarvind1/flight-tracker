// Offscreen document — has DOM access for HTML parsing

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PARSE_HTML') {
    const flights = parseFlightsHtml(message.html);
    sendResponse({ flights });
  }
  return true;
});

function parseFlightsHtml(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const flights = [];

  const groups = doc.querySelectorAll('div[jsname="IWWDBc"], div[jsname="YdtKid"]');

  groups.forEach((group, groupIndex) => {
    const isBest = groupIndex === 0;
    const items = group.querySelectorAll('ul.Rk10dc li');

    items.forEach((item, itemIndex) => {
      if (!isBest && itemIndex === items.length - 1) return;

      const name = item.querySelector('div.sSHqwe.tPgKwe.ogfYpf span')?.textContent?.trim() || '';
      const timeNodes = item.querySelectorAll('span.mv1WYe div');
      const departure = timeNodes[0]?.textContent?.trim() || '';
      const arrival = timeNodes[1]?.textContent?.trim() || '';
      const duration = item.querySelector('li div.Ak5kof div')?.textContent?.trim() || '';
      const stopsText = item.querySelector('.BbR8Ec .ogfYpf')?.textContent?.trim() || '';
      const priceText = item.querySelector('.YMlIz.FpEdX')?.textContent?.trim() || '0';

      let stops = 0;
      if (stopsText && stopsText !== 'Nonstop') {
        const m = stopsText.match(/(\d+)/);
        if (m) stops = parseInt(m[1]);
      }

      const price = parseInt(priceText.replace(/[^\d]/g, '')) || 0;
      if (price === 0) return;

      let durationMinutes = 0;
      const hMatch = duration.match(/(\d+)\s*hr?/);
      const mMatch = duration.match(/(\d+)\s*min/);
      if (hMatch) durationMinutes += parseInt(hMatch[1]) * 60;
      if (mMatch) durationMinutes += parseInt(mMatch[1]);

      flights.push({
        airline: name || 'Unknown',
        price,
        currency: 'USD',
        departureTime: departure,
        arrivalTime: arrival,
        durationMinutes,
        stops,
        isBest,
      });
    });
  });

  return flights;
}

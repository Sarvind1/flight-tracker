// === CONFIG (loaded from config.js via importScripts) ===

importScripts('config.js');

const CONFIG = {
  convexHttpUrl: FTRACK_CONFIG.convexHttpUrl,
  scraperToken: FTRACK_CONFIG.scraperToken,
};

// === EXTERNAL MESSAGES (from ftrack web page via content script) ===

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_NOW') {
    sendResponse({ status: 'started' });
    runFetch('manual');
  }
  if (message.type === 'GET_STATUS') {
    chrome.storage.local.get(['lastFetchDate', 'fetching']).then((status) => {
      sendResponse(status);
    });
    return true;
  }
  if (message.type === 'PING') {
    sendResponse({ installed: true });
  }
  return true;
});

// === INTERNAL MESSAGES (from popup + content script) ===

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_NOW') {
    sendResponse({ status: 'started' });
    runFetch('manual');
  }
  if (message.type === 'FETCH_ROUTE') {
    // Fetch specific targets by IDs
    sendResponse({ status: 'started' });
    runFetchTargets(message.targetIds, 'manual-route');
  }
  if (message.type === 'PARSE_HTML') {
    // Forward to offscreen — but this comes FROM offscreen, so skip
    // (offscreen listens for this itself)
  }
  return true;
});

// === CORE LOGIC ===

async function autoFetchIfNeeded() {
  if (!CONFIG.convexHttpUrl || !CONFIG.scraperToken) return;

  const { fetching } = await chrome.storage.local.get('fetching');
  if (fetching) return;

  try {
    // Ask Convex which targets are stale (not fetched in 24h)
    const res = await fetch(`${CONFIG.convexHttpUrl}/sync/stale-targets`, {
      headers: { 'Authorization': `Bearer ${CONFIG.scraperToken}` },
    });
    if (!res.ok) return;
    const staleTargets = await res.json();

    if (staleTargets.length === 0) {
      console.log('All targets are fresh — nothing to fetch');
      setBadge('ok');
      return;
    }

    console.log(`${staleTargets.length} stale targets — fetching...`);
    await fetchAndPostTargets(staleTargets, 'auto-catchup');
  } catch (err) {
    console.error('Auto-fetch check failed:', err);
  }
}

// Fetch ALL active routes
async function runFetch(source) {
  await chrome.storage.local.set({ fetching: true });
  setBadge('fetching');

  try {
    const targetsRes = await fetch(`${CONFIG.convexHttpUrl}/sync/targets`, {
      headers: { 'Authorization': `Bearer ${CONFIG.scraperToken}` },
    });
    if (!targetsRes.ok) throw new Error(`Targets: ${targetsRes.status}`);
    const targets = await targetsRes.json();

    if (targets.length === 0) {
      console.log('No targets to fetch');
      await chrome.storage.local.set({ fetching: false });
      setBadge('ok');
      return;
    }

    await fetchAndPostTargets(targets, source);
  } catch (err) {
    console.error('Fetch run failed:', err);
    await chrome.storage.local.set({ fetching: false });
    setBadge('error');
  }
}

// Fetch specific targets by ID (for per-route refresh)
async function runFetchTargets(targetIds, source) {
  await chrome.storage.local.set({ fetching: true });
  setBadge('fetching');

  try {
    // Get all targets, filter to the ones we want
    const targetsRes = await fetch(`${CONFIG.convexHttpUrl}/sync/targets`, {
      headers: { 'Authorization': `Bearer ${CONFIG.scraperToken}` },
    });
    if (!targetsRes.ok) throw new Error(`Targets: ${targetsRes.status}`);
    const allTargets = await targetsRes.json();
    const targets = allTargets.filter(t => targetIds.includes(t._id));

    if (targets.length === 0) {
      console.log('No matching targets');
      await chrome.storage.local.set({ fetching: false });
      setBadge('ok');
      return;
    }

    await fetchAndPostTargets(targets, source);
  } catch (err) {
    console.error('Route fetch failed:', err);
    await chrome.storage.local.set({ fetching: false });
    setBadge('error');
  }
}

// Shared: fetch Google Flights for a list of targets, post results to Convex
async function fetchAndPostTargets(targets, source) {
  const runStartedAt = Date.now();
  const results = [];

  for (let i = 0; i < targets.length; i++) {
    const target = targets[i];
    console.log(`[${i + 1}/${targets.length}] ${target.origin}→${target.destination} on ${target.departureDate}`);

    try {
      const tfs = buildTfsParam(
        target.origin,
        target.destination,
        target.departureDate,
        target.returnDate,
        target.tripType,
        target.cabin,
        target.passengers
      );

      const url = `https://www.google.com/travel/flights?tfs=${tfs}&hl=en&tfu=EgQIABABIgA&curr=USD`;
      const res = await fetch(url);
      const html = await res.text();
      const flights = await parseFlightsHtml(html);
      console.log(`  Got ${flights.length} flights`);

      results.push({
        targetId: target._id,
        status: flights.length > 0 ? 'ok' : 'sparse',
        quotes: flights,
      });
    } catch (err) {
      console.error(`  Error: ${err.message}`);
      results.push({
        targetId: target._id,
        status: 'error',
        quotes: [],
        error: err.message,
      });
    }

    if (i < targets.length - 1) {
      await sleep(2000 + Math.random() * 4000);
    }
  }

  // Post results in batches of 3
  const BATCH = 3;
  for (let i = 0; i < results.length; i += BATCH) {
    const batch = results.slice(i, i + BATCH);
    const postRes = await fetch(`${CONFIG.convexHttpUrl}/sync/quotes`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${CONFIG.scraperToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ runStartedAt, results: batch }),
    });
    if (!postRes.ok) console.error(`Post batch failed: ${postRes.status}`);
  }

  const today = new Date().toISOString().split('T')[0];
  await chrome.storage.local.set({ lastFetchDate: today, fetching: false, lastSource: source });
  setBadge('ok');
  console.log(`Done. ${results.filter((r) => r.status === 'ok').length}/${results.length} succeeded`);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function setBadge(state) {
  const colors = { ok: '#22c55e', fetching: '#eab308', error: '#ef4444' };
  const texts = { ok: '✓', fetching: '...', error: '!' };
  chrome.action.setBadgeBackgroundColor({ color: colors[state] || '#666' });
  chrome.action.setBadgeText({ text: texts[state] || '' });
}

// === PROTOBUF ENCODING ===

function encodeVarint(value) {
  const bytes = [];
  while (value > 127) {
    bytes.push((value & 0x7f) | 0x80);
    value >>>= 7;
  }
  bytes.push(value & 0x7f);
  return bytes;
}

function encodeTag(fieldNumber, wireType) {
  return encodeVarint((fieldNumber << 3) | wireType);
}

function encodeStringField(fieldNumber, value) {
  const encoded = new TextEncoder().encode(value);
  return [...encodeTag(fieldNumber, 2), ...encodeVarint(encoded.length), ...encoded];
}

function encodeMessage(fieldNumber, messageBytes) {
  return [...encodeTag(fieldNumber, 2), ...encodeVarint(messageBytes.length), ...messageBytes];
}

function encodeVarintField(fieldNumber, value) {
  return [...encodeTag(fieldNumber, 0), ...encodeVarint(value)];
}

function encodePackedField(fieldNumber, values) {
  const packed = values.flatMap((v) => encodeVarint(v));
  return [...encodeTag(fieldNumber, 2), ...encodeVarint(packed.length), ...packed];
}

function buildTfsParam(origin, destination, date, returnDate, tripType, cabin, passengers) {
  const fromAirport = encodeStringField(2, origin);
  const toAirport = encodeStringField(2, destination);

  const flightData = [
    ...encodeStringField(2, date),
    ...encodeMessage(13, fromAirport),
    ...encodeMessage(14, toAirport),
  ];

  let infoBytes = [...encodeMessage(3, flightData)];

  if (returnDate && tripType === 'round_trip') {
    const returnFlight = [
      ...encodeStringField(2, returnDate),
      ...encodeMessage(13, encodeStringField(2, destination)),
      ...encodeMessage(14, encodeStringField(2, origin)),
    ];
    infoBytes.push(...encodeMessage(3, returnFlight));
  }

  const seatMap = { ECONOMY: 1, PREMIUM_ECONOMY: 2, BUSINESS: 3, FIRST: 4 };
  const tripMap = { round_trip: 1, one_way: 2 };

  const passengerValues = Array(passengers || 1).fill(1);
  infoBytes.push(...encodePackedField(8, passengerValues));
  infoBytes.push(...encodeVarintField(9, seatMap[cabin] || 1));
  infoBytes.push(...encodeVarintField(19, tripMap[tripType] || 2));

  const bytes = new Uint8Array(infoBytes);
  return btoa(String.fromCharCode(...bytes));
}

// === HTML PARSING (via offscreen document — service workers have no DOM) ===

async function ensureOffscreen() {
  // Check if one already exists
  const existing = await chrome.offscreen.hasDocument();
  if (existing) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['DOM_PARSER'],
    justification: 'Parse Google Flights HTML response',
  });
}

async function parseFlightsHtml(html) {
  await ensureOffscreen();
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'PARSE_HTML', html }, (response) => {
      resolve(response?.flights || []);
    });
  });
}

// === HOURLY STALE CHECK ===
// Light check — only asks Convex "anything stale?". No Google calls unless needed.

chrome.alarms.create('staleCheck', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'staleCheck') {
    console.log('Hourly stale check...');
    await autoFetchIfNeeded();
  }
});

// === STARTUP ===

chrome.runtime.onStartup.addListener(() => {
  autoFetchIfNeeded();
});

chrome.runtime.onInstalled.addListener(() => {
  autoFetchIfNeeded();
});

// Listen for network restore — catch up after offline periods
self.addEventListener('online', () => {
  console.log('Network restored — checking for stale targets');
  autoFetchIfNeeded();
});

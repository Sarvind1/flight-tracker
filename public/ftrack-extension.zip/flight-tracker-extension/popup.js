const fetchBtn = document.getElementById('fetch');
const statusEl = document.getElementById('status');

// Update status on open
updateStatus();

fetchBtn.addEventListener('click', () => {
  fetchBtn.disabled = true;
  fetchBtn.innerHTML = `
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 8a5 5 0 1 1-1.5-3.5"/><polyline points="13,2 13,5 10,5"/></svg>
    Fetching...
  `;

  chrome.runtime.sendMessage({ type: 'FETCH_NOW' }, () => {
    const poll = setInterval(async () => {
      const status = await chrome.storage.local.get('fetching');
      if (!status.fetching) {
        clearInterval(poll);
        fetchBtn.disabled = false;
        fetchBtn.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 8a5 5 0 1 1-1.5-3.5"/><polyline points="13,2 13,5 10,5"/></svg>
          Fetch prices now
        `;
        updateStatus();
      }
    }, 2000);
  });
});

async function updateStatus() {
  // Check if config is set
  if (!FTRACK_CONFIG.convexHttpUrl || !FTRACK_CONFIG.scraperToken) {
    statusEl.innerHTML = '<span class="dot none"></span> Not configured — edit config.js';
    return;
  }

  const data = await chrome.storage.local.get(['lastFetchDate', 'fetching', 'lastSource']);

  if (data.fetching) {
    statusEl.innerHTML = '<span class="dot fetching"></span> Fetching prices...';
    return;
  }

  const today = new Date().toISOString().split('T')[0];
  if (data.lastFetchDate === today) {
    const via = data.lastSource === 'auto' ? 'auto-check' : 'manual';
    statusEl.innerHTML = `<span class="dot ok"></span> Prices fresh today<br>(via ${via})`;
  } else if (data.lastFetchDate) {
    statusEl.innerHTML = `<span class="dot stale"></span> Last fetch: ${data.lastFetchDate}<br>Click above to refresh`;
  } else {
    statusEl.innerHTML = '<span class="dot none"></span> Ready — click above to fetch';
  }
}

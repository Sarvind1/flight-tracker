// Content script injected on ftrack pages.
// Relays messages between the web page and the background service worker.

// Announce presence
window.postMessage({ type: 'FTRACK_EXTENSION_INSTALLED', extensionId: chrome.runtime.id }, '*');

// Listen for messages from the page
window.addEventListener('message', async (event) => {
  if (event.source !== window) return;

  if (event.data?.type === 'FTRACK_FETCH_NOW') {
    chrome.runtime.sendMessage({ type: 'FETCH_NOW' }, (response) => {
      window.postMessage({ type: 'FTRACK_FETCH_STARTED', ...response }, '*');
    });
  }

  if (event.data?.type === 'FTRACK_FETCH_ROUTE') {
    chrome.runtime.sendMessage({ type: 'FETCH_ROUTE', targetIds: event.data.targetIds }, (response) => {
      window.postMessage({ type: 'FTRACK_FETCH_STARTED', ...response }, '*');
    });
  }

  if (event.data?.type === 'FTRACK_GET_STATUS') {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
      window.postMessage({ type: 'FTRACK_STATUS', ...(response || {}) }, '*');
    });
  }
});

// Re-announce periodically in case page loaded before content script
setInterval(() => {
  window.postMessage({ type: 'FTRACK_EXTENSION_INSTALLED', extensionId: chrome.runtime.id }, '*');
}, 5000);

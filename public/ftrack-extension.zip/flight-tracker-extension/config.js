// ============================================================
// ftrack extension config
// ============================================================
// Pre-configured — no setup needed for friends.
// The token ensures only people with this extension can push data.
// ============================================================

const FTRACK_CONFIG = {
  convexHttpUrl: "https://reliable-wolf-26.convex.site",
  scraperToken: "ftrack-prod-7d7ab82703d6c913",
};
